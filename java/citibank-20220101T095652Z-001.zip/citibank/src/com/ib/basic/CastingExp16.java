package com.ib.basic;

public class CastingExp16 {
	
	// Casting -  explicit casting

	public static void main(String[] args) {

		
		int i=10;
		
		double k = i;
		
		byte j=(byte) i;
		
		
		
		
	}

}
