package com.ib.basic;

public class ClassExp1 {

	void createCustomer() {

	}

	void createCustomer1() {

	}

	void createCustomer2() {

	}

}
