package com.ib.basic;

public class ClassWithTwoMethod2 {

	void createLoanDet() {
		System.out.println("Hi from method...");
	}

	public static void main(String[] args) {
		System.out.println("Hello from main method **********...");
	}

}
