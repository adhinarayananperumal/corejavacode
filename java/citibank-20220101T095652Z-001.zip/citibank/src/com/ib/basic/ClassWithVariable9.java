package com.ib.basic;

public class ClassWithVariable9 {

	public static void main(String[] args) {

		
		String fname="ravi";
		int age=26;
		long mobileno=984568321;
		String emailid="ravi@gmail.com";
		
		System.out.println(fname);
		
		System.out.println(age);
		
		System.out.println("Age is : " + age);


		System.out.println(fname + " age is : " + age);

		
	}

}
