package com.ib.basic;

public class LocalInstanceStaticVariableExp12 {

	public static void main(String[] args) {

		
		EmployeeServiceImpl employeeServiceImpl = new EmployeeServiceImpl();
		
		employeeServiceImpl.saveEmployee();
		employeeServiceImpl.save();

		
	}

}
