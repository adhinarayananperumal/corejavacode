package com.ib.basic;

public class MarkPojo {

	
	// private encapsulation should be applied - Encapulation
	int eng;
	int tam;
	int mat;
	int sic;
	int his;
	String stuName;
	float total;
	public static final String collegeName="sss";
	int cs;
	
	
	
	public int getCs() {
		return cs;
	}
	public void setCs(int cs) {
		this.cs = cs;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getTam() {
		return tam;
	}
	public void setTam(int tam) {
		this.tam = tam;
	}
	public int getMat() {
		return mat;
	}
	public void setMat(int mat) {
		this.mat = mat;
	}
	public int getSic() {
		return sic;
	}
	public void setSic(int sic) {
		this.sic = sic;
	}
	public int getHis() {
		return his;
	}
	public void setHis(int his) {
		this.his = his;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public static String getCollegename() {
		return collegeName;
	}
	

	
	
	
}
