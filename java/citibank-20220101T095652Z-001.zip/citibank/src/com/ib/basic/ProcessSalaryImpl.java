package com.ib.basic;

public class ProcessSalaryImpl {
	
	 void credit(){
		System.out.println("credit method called Credited.....");
	}

	
	static void creditSalary(){
		System.out.println("Salary Credited.....");
	}

}
