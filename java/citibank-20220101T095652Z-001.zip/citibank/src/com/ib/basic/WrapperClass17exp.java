package com.ib.basic;

public class WrapperClass17exp {

	// Wrapper class

	public static void main(String[] args) {

		String stuid = "101";

		// gives error
		// int sid = stuid;

		int sid = Integer.parseInt(stuid);

	}

}
