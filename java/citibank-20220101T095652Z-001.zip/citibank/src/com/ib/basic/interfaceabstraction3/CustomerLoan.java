package com.ib.basic.interfaceabstraction3;

public class CustomerLoan extends  AbstractClassLoanImpl {

	@Override
	public void saveLoan(LoanPojo loanPojo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateloan(LoanPojo loanPojo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected String processLoan() {
		// TODO Auto-generated method stub
		return null;
	}

}
