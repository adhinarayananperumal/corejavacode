package com.ib.collectionexp;

public class TicketPojo {

	private String travelerName;
	private String trainNo;
	private String trainDestination;
	private float tickerFare;

	
	public String getTravelerName() {
		return travelerName;
	}

	public void setTravelerName(String travelerName) {
		this.travelerName = travelerName;
	}

	public String getTrainNo() {
		return trainNo;
	}

	public void setTrainNo(String trainNo) {
		this.trainNo = trainNo;
	}

	public String getTrainDestination() {
		return trainDestination;
	}

	public void setTrainDestination(String trainDestination) {
		this.trainDestination = trainDestination;
	}

	public float getTickerFare() {
		return tickerFare;
	}

	public void setTickerFare(float tickerFare) {
		this.tickerFare = tickerFare;
	}

}
