package com.ib.database;

public class ConnectionCreationFailed extends Exception{

}
