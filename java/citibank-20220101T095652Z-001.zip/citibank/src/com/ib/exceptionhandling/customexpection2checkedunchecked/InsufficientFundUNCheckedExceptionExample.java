package com.ib.exceptionhandling.customexpection2checkedunchecked;

public class InsufficientFundUNCheckedExceptionExample extends RuntimeException{

}
