package com.ib.exceptionhandling1;

public class SimpleExceptionhandlingExample1 {

	void call() {
		System.out.println("line 1");
		System.out.println("line 2");
		String name = "tcsyyyyrXuZyyyyyyyyyyyyyyyyyyyyyyy";
		System.out.println("line 4");
		char val = name.charAt(206);
		System.out.println("line 6  " + val + "");
		System.out.println("execution ended successfully");
	}

}
