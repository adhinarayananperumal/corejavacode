package com.ib.exceptionhandling1;

public class Test1 {

	public static void main(String[] args) {
		SimpleExceptionhandlingExample1 simpleExceptionhandlingExample1 = new SimpleExceptionhandlingExample1();
		simpleExceptionhandlingExample1.call();
		System.out.println("Program execution end");
	}

}
