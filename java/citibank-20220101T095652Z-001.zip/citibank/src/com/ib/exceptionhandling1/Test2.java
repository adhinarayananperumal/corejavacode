package com.ib.exceptionhandling1;

public class Test2 {

	public static void main(String[] args) {
		SimpleExceptionHandling2 simpleExceptionhandlingExample2 = new SimpleExceptionHandling2();
		simpleExceptionhandlingExample2.call();
		System.out.println("Program returned ");
	}

}
