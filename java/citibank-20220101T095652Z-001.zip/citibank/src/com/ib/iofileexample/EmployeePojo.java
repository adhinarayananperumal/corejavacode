package com.ib.iofileexample;

import java.io.Serializable;

public class EmployeePojo implements Serializable {

	private String empId;
	private String empName;
	private int age;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
