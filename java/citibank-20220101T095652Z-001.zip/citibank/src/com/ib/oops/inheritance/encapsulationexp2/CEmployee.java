package com.ib.oops.inheritance.encapsulationexp2;

public class CEmployee extends EmployeeImpl {

	private void testSub() {
		System.out.println("test sub is called");
	}

	public void save() {

	}

}
