package com.ib.oops.inheritance.encapsulationexp2;

// this class is eligible to use from other class in the same package

  class DefaultModifierClass {
	  
	  String cname="SSS";
	
	void save(){
		System.out.println("default save method called");
	}
	
	void update(){
		System.out.println(" update method called");
	}

	

}
