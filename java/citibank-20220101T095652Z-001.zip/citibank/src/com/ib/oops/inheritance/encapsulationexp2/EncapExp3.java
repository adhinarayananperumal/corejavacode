package com.ib.oops.inheritance.encapsulationexp2;

public class EncapExp3 {

	public static void main(String[] args) {

		CEmployee cemployeeImpl = new CEmployee();
		cemployeeImpl.generateEmpId();

		PEmployee pemployeeImpl = new PEmployee();
		pemployeeImpl.generateEmpId();

	}

}
