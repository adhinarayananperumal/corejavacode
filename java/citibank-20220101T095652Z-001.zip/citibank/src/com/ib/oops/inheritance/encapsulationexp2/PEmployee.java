package com.ib.oops.inheritance.encapsulationexp2;

public class PEmployee extends EmployeeImpl {

	void save() {
		
		System.out.println("Save employee");

	}

}
