package com.ib.oops.inheritance.encapsulationexp2;

public class ProtectedMethodCallTest3 {

	public static void main(String[] args) {

		CEmployee cemployeeImpl = new CEmployee();
		cemployeeImpl.generateEmpId();
		
		DefaultModifierClass DefaultModifierClass = new DefaultModifierClass();


	}

}
