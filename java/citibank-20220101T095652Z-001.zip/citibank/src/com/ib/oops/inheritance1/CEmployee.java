package com.ib.oops.inheritance1;

public class CEmployee extends EmployeeImpl{
	
	void save(){
		
	}

}
