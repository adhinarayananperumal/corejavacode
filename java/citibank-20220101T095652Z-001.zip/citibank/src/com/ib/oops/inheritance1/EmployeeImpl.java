package com.ib.oops.inheritance1;

public class EmployeeImpl {
	
	// public protected private

	protected void generateEmpId() {

		System.out.println("Employee id generated...");
	}

}
