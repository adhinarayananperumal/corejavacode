package com.ib.oops.inheritance1;


public class InheritanceExpTest1 {

	public static void main(String[] args) {

		CEmployee cemployeeImpl = new CEmployee();
		cemployeeImpl.generateEmpId();

		PEmployee pemployeeImpl = new PEmployee();
		pemployeeImpl.generateEmpId();
		

	}

}
