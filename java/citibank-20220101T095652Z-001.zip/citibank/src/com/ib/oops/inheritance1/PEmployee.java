package com.ib.oops.inheritance1;

public class PEmployee extends EmployeeImpl {

	void save() {
		
		System.out.println("Save employee");

	}

}
