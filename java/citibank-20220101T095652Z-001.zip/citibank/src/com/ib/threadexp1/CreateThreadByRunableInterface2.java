package com.ib.threadexp1;

public class CreateThreadByRunableInterface2 implements  Runnable {

	public void run() {
		System.out.println(" Thread 2 line1 thread class");
		System.out.println("Thread 2 CreateThreadByThreadClassProcessFeedFile1 thread is running...");
		System.out.println("Thread 2line3");
		System.out.println("Thread 2line4");
		System.out.println("Thread 2line5  end of methos run ie thread");
	}

}
