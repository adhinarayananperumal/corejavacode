package com.ib.threadexp1;

public class SleepExample4 implements Runnable{
	
	
	public void run() {
		System.out.println("Thread 4 line1 thread class");
		System.out.println("Thread 4 sleepExample thread is running...");
		System.out.println("Thread 4 line3");	
		System.out.println("Thread 4 line4");
		System.out.println("Thread 4 line5  end of run() method  - thread ended ");
	}


}
